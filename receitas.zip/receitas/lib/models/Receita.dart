class Receita {
  String idreceita, nome, img, ingredientes, categoria, preparo, dia, color;

  Receita(this.idreceita, this.nome, this.img, this.ingredientes, this.categoria, this.preparo, this.dia, this.color);
}
